// MCQ/MCS-style max-clique decision: is there a clique of size K?  bitset, degree-sorted relabel
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MW 8
int n,K,W; uint64_t adj[512][MW]; long long nodes;
int deg0[512], perm[512];
static int popc(const uint64_t*x){int c=0;for(int i=0;i<W;i++)c+=__builtin_popcountll(x[i]);return c;}
static int ordv[64][512],colv[64][512];
int expand(uint64_t*P,int need,int dep){
  nodes++;
  if(need<=0) return 1;
  int cnt=popc(P); if(cnt<need) return 0;
  uint64_t Q[MW],R[MW]; memcpy(Q,P,8*W);
  int *ord=ordv[dep],*col=colv[dep],m=0,c=0;
  // greedy colouring in vertex (=priority) order; vertices with colour < need-? are not branched on
  int kmin = need; // colours < kmin go first (they can't lead to solution alone)
  while(1){ int any=0; for(int i=0;i<W;i++) if(Q[i]){any=1;break;} if(!any)break;
    c++; memcpy(R,Q,8*W);
    for(int w=0;w<W;w++) while(R[w]){ int b=__builtin_ctzll(R[w]); int v=w*64+b; R[w]&=R[w]-1; Q[w]&=~(1ULL<<b);
       for(int j=0;j<W;j++) R[j]&=~adj[v][j]; ord[m]=v; col[m]=c; m++; } }
  if(c<need) return 0;
  uint64_t PP[MW]; memcpy(PP,P,8*W);
  for(int i=m-1;i>=0;i--){ if(col[i]<need) return 0;
    int v=ord[i]; uint64_t NP[MW]; for(int j=0;j<W;j++) NP[j]=PP[j]&adj[v][j];
    if(expand(NP,need-1,dep+1)) return 1;
    PP[v>>6]&=~(1ULL<<(v&63)); }
  return 0;
}
int ea[100000],eb[100000];
int cmp(const void*a,const void*b){return deg0[*(int*)b]-deg0[*(int*)a];}
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); K=atoi(argv[2]); int w; fscanf(f,"%d %d",&n,&w);
  int ne=0,a,b; while(fscanf(f,"%d %d",&a,&b)==2){ea[ne]=a;eb[ne]=b;ne++;deg0[a]++;deg0[b]++;}
  for(int i=0;i<n;i++)perm[i]=i; qsort(perm,n,sizeof(int),cmp);  // high degree first -> low index
  int inv[512]; for(int i=0;i<n;i++) inv[perm[i]]=i;
  W=(n+63)/64;
  for(int e=0;e<ne;e++){int x=inv[ea[e]],y=inv[eb[e]]; adj[x][y>>6]|=1ULL<<(y&63); adj[y][x>>6]|=1ULL<<(x&63);}
  uint64_t P[MW]; memset(P,0,sizeof P); for(int i=0;i<n;i++) P[i>>6]|=1ULL<<(i&63);
  int r=expand(P,K,0);
  printf("%s rep=%d n=%d K=%d result=%s nodes=%lld\n",argv[1],w,n,K,r?"CLIQUE_EXISTS":"NO_CLIQUE",nodes);
  return 0;
}
