"""Best-known lower bounds for two-colour Ramsey numbers R(k,l), from
Radziszowski DS1 revision #18 (24 Apr 2026), plus 2026 AlphaEvolve updates.
L[(k,l)] = B means R(k,l) >= B is known (some graph on B-1 vertices exists).
Then closes the table under the general lower-bound inequalities 2.3.e/g/h/i,
so that "improvement" claims are never made against a trivially implied value.
Writes bounds.txt: k l B listed(0/1)
"""
KMAX, LMAX = 12, 60
L = {}
def put(k, row):  # row: dict l->B
    for l, b in row.items():
        L[(k, l)] = max(L.get((k, l), 0), b)

put(3, {3:6,4:9,5:14,6:18,7:23,8:28,9:36,10:40,11:47,12:53,13:61,14:67,15:74,
        16:82,17:92,18:100,19:106,20:111,21:122,22:131,23:139,24:143,25:154,26:161,
        27:172,28:179,29:190,30:197,31:208,32:217,33:227,34:234,35:248,36:255,37:267,
        38:278,39:290,40:298,41:311,42:320,43:333,44:339,45:354,46:362,47:380,48:384,49:402})
put(4, {4:18,5:25,6:36,7:49,8:59,9:73,10:92,11:102,12:128,13:139,14:148,15:159,
        16:174,17:200,18:209,19:219,20:237,21:242,22:314,25:458})
put(5, {5:43,6:59,7:80,8:101,9:133,10:149,11:183,12:203,13:233,14:267,15:275,
        16:293,17:388,18:396,19:411,20:424,21:441,22:492,23:521})
put(6, {6:102,7:115,8:134,9:183,10:204,11:262,12:294,13:347,15:401,
        16:434,17:548,18:614,19:710,20:878,21:888,22:1070})
put(7, {7:205,8:219,9:252,10:292,11:405,12:417,13:511,16:629,17:729,18:797,19:908,21:1214})
put(8, {8:282,9:329,10:343,11:457,13:817,15:873,17:1005,18:1049,19:1237,21:1617})
put(9, {9:565,10:581,17:1411})
put(10, {10:798,15:1313})
put(11, {11:1597}); put(12, {12:1640})

listed = set(L)
B = {}
for k in range(1, KMAX+1):
    for l in range(1, LMAX+1):
        a, b = min(k, l), max(k, l)
        B[(k, l)] = L.get((a, b), 0)
for k in range(1, KMAX+1):
    for l in range(1, LMAX+1):
        if min(k, l) == 1: B[(k, l)] = 1
        if min(k, l) == 2: B[(k, l)] = max(k, l)

def g(k, l): return B.get((k, l), 0)
changed = True
while changed:
    changed = False
    for k in range(3, KMAX+1):
        for l in range(3, LMAX+1):
            v = g(k, l)
            c = [g(k, l-1) + 2*k - 3, g(k-1, l) + 2*l - 3]          # 2.3.e
            for p in range(2, l):                                     # 2.3.g/h
                q = l + 1 - p
                if 2 <= p <= q:
                    c.append(g(k, p) + g(k, q) + (k-2 if k >= 5 else k-3))
                    c.append(g(k, p) + g(k, q) + p - 2)
            if k % 2 == 1 and l >= 5:                                 # 2.3.i
                kk = (k+1)//2
                if kk >= 2: c.append(4*g(kk, l-1) - 3)
            nv = max([v] + c)
            if nv > v:
                B[(k, l)] = nv; B[(l, k)] = max(B.get((l, k), 0), nv)
                if l <= KMAX: B[(l, k)] = nv
                changed = True

with open('bounds.txt', 'w') as f:
    for k in range(3, KMAX+1):
        for l in range(k, LMAX+1):
            f.write(f"{k} {l} {B[(k,l)]} {int((k,l) in listed)}\n")
if __name__ == '__main__':
    for k in range(5, 11):
        print(k, [(l, B[(k, l)], '*' if (k, l) in listed else '') for l in range(k, 24)])
