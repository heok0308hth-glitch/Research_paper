// Cyclotomic Ramsey atlas: for primes p and divisors d of p-1, enumerate
// symmetric unions S of cyclotomic classes C_i = g^i <g^d> (up to the
// multiplier rotation i -> i+1), build the Cayley graph Cay(Z_p, S), compute
// omega exactly and decide whether alpha is below the threshold that would
// beat the best known lower bound for R(omega+1, l).
//
// Symmetry used:  translations x->x+c (vertex transitive) and multipliers
// x->hx, h in <g^d> (fix 0, act transitively on each class).  Hence
//   omega = 2 + max_{i in S}    omega(G[N(0) ∩ N(g^i)])
//   alpha >= l  iff  exists i notin S with a clique of size l-2 in the
//               complement restricted to the common non-neighbourhood of 0,g^i.
//
// usage: cyc pmin pmax dmin dmax nodelimit [kmin]
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define MAXN 2112
#define MAXW (MAXN/64+1)
#define MAXD 64

static int N, W;
static uint64_t A[MAXN][MAXW];   // current graph (G or complement)
static uint64_t G0[2*MAXW+2];
static int Bnd[64][128];         // Bnd[k][l] lower bounds
static long long nodes, nodelimit;
static int aborted;

static inline int popc(const uint64_t *x){int c=0;for(int i=0;i<W;i++)c+=__builtin_popcountll(x[i]);return c;}
static inline int empty(const uint64_t *x){for(int i=0;i<W;i++)if(x[i])return 0;return 1;}

static int ordv[40][MAXN], colv[40][MAXN];

// does P contain a clique of size need (in graph A)? 1 yes, 0 no, -1 aborted
static int clq(uint64_t *P, int need, int depth){
    if(need<=0) return 1;
    if(++nodes > nodelimit){aborted=1;return -1;}
    int cnt=popc(P);
    if(cnt<need) return 0;
    if(need==1) return cnt>0;
    uint64_t Q[MAXW], R[MAXW];
    memcpy(Q,P,8*W);
    int n=0,c=0;
    int *ord=ordv[depth], *col=colv[depth];
    while(!empty(Q)){
        c++;
        memcpy(R,Q,8*W);
        for(int w=0;w<W;w++){
            while(R[w]){
                int b=__builtin_ctzll(R[w]); int v=w*64+b;
                R[w]&=R[w]-1; Q[w]&=~(1ULL<<b);
                for(int j=0;j<W;j++) R[j]&=~A[v][j];
                ord[n]=v; col[n]=c; n++;
            }
        }
    }
    uint64_t PP[MAXW]; memcpy(PP,P,8*W);
    for(int i=n-1;i>=0;i--){
        if(col[i]<need) return 0;
        int v=ord[i];
        uint64_t NP[MAXW];
        for(int j=0;j<W;j++) NP[j]=PP[j]&A[v][j];
        int r=clq(NP,need-1,depth+1);
        if(r) return r;
        PP[v>>6]&=~(1ULL<<(v&63));
    }
    return 0;
}

static int pw(long long b,long long e,long long m){long long r=1;b%=m;while(e){if(e&1)r=r*b%m;b=b*b%m;e>>=1;}return (int)r;}
static int primroot(int p){
    int f[32],nf=0,x=p-1;
    for(int q=2;q*q<=x;q++) if(x%q==0){f[nf++]=q;while(x%q==0)x/=q;}
    if(x>1)f[nf++]=x;
    for(int g=2;g<p;g++){int ok=1;for(int i=0;i<nf;i++) if(pw(g,(p-1)/f[i],p)==1){ok=0;break;} if(ok)return g;}
    return -1;
}
static int isprime(int n){if(n<2)return 0;for(int q=2;q*q<=n;q++)if(n%q==0)return 0;return 1;}

static int ind[MAXN], gpow[MAXN];

// build circulant graph from row0 bits (set of differences)
static void build(const char *inS){
    memset(G0,0,sizeof(G0));
    for(int u=1;u<N;u++) if(inS[u]){ G0[u>>6]|=1ULL<<(u&63); G0[(u+N)>>6]|=1ULL<<((u+N)&63);}  // doubled
    // row v: bit u set iff (u - v) mod N in S  -> bits of doubled string starting at offset N - v
    for(int v=0;v<N;v++){
        int off=N-v; // take bits off .. off+N-1
        int ws=off>>6, bs=off&63;
        for(int j=0;j<W;j++){
            uint64_t lo=G0[ws+j]>>bs;
            uint64_t hi= bs? (G0[ws+j+1]<<(64-bs)) : 0;
            A[v][j]=lo|hi;
        }
        int r=N&63; if(r) A[v][W-1]&=(1ULL<<r)-1;
    }
}

static int bestk_l(int k,int p){ // LARGEST l>=k with Bnd[k][l] <= p: a graph on p vertices with omega<k, alpha<l improves R(k,l)
    int best=-1;
    for(int l=k;l<=60;l++) if(Bnd[k][l] && Bnd[k][l]<=p) best=l;
    return best;
}

int main(int argc,char**argv){
    int pmin=atoi(argv[1]),pmax=atoi(argv[2]),dmin=atoi(argv[3]),dmax=atoi(argv[4]);
    long long lim=atoll(argv[5]); int kmin= argc>6?atoi(argv[6]):5;
    FILE*f=fopen(argc>7?argv[7]:"bounds.txt","r");
    int k,l,b,li; while(fscanf(f,"%d %d %d %d",&k,&l,&b,&li)==4){Bnd[k][l]=b; if(l<64)Bnd[l][k]=b;}
    fclose(f);
    char inS[MAXN];
    long long ngraphs=0;
    for(int p=pmin;p<=pmax;p++){ if(!isprime(p))continue;
        N=p; W=(N+63)/64;
        int g=primroot(p);
        long long x=1; for(int j=0;j<p-1;j++){ind[x]=j;gpow[j]=(int)x;x=x*g%p;}
        for(int d=dmin;d<=dmax && d<=MAXD;d++){ if((p-1)%d)continue;
            int symm = ((p-1)/d)%2==0;   // -1 in subgroup
            int half=d/2;
            int nfree = symm? d : half;
            for(long long m=1;m< (1LL<<nfree);m++){
                // full mask over d classes
                unsigned long long M = symm? (unsigned long long)m : ((unsigned long long)m | ((unsigned long long)m<<half));
                int pc=__builtin_popcountll(M);
                if(2*pc>d) continue;
                // canonical under rotation
                int canon=1; unsigned long long full=(d==64)?~0ULL:((1ULL<<d)-1);
                for(int r=1;r<d;r++){unsigned long long R=((M<<r)|(M>>(d-r)))&full; if(R<M){canon=0;break;}}
                if(!canon) continue;
                ngraphs++;
                for(int u=1;u<p;u++) inS[u]=(M>>(ind[u]%d))&1;
                inS[0]=0;
                build(inS);
                // omega
                int omega=1; int maxom=11;
                for(int i=0;i<d;i++) if((M>>i)&1){
                    int v=gpow[i]; uint64_t P[MAXW];
                    for(int j=0;j<W;j++) P[j]=A[0][j]&A[v][j];
                    // find max clique in P incrementally
                    int t=omega-1; // need clique of size t-1 more... compute omega_i = 2+maxclique(P)
                    while(1){ nodes=0; nodelimit=50000000; aborted=0;
                        int need=omega-1; // to beat current omega need clique of size omega-1 in P
                        if(need+2>maxom){omega=99;break;}
                        int r=clq(P,need,0);
                        if(r==1) omega++; else break; }
                    (void)t;
                    if(omega>=maxom) break;
                }
                if(kmin==0){ // test mode: exact alpha
                    for(int v=0;v<p;v++){ for(int j=0;j<W;j++) A[v][j]=~A[v][j]; A[v][v>>6]&=~(1ULL<<(v&63)); int r=p&63; if(r)A[v][W-1]&=(1ULL<<r)-1; }
                    int alpha=2;
                    for(int i=0;i<d;i++) if(!((M>>i)&1)){ int v=gpow[i]; uint64_t P[MAXW];
                        for(int j=0;j<W;j++) P[j]=A[0][j]&A[v][j];
                        while(1){nodes=0;nodelimit=lim;aborted=0; int r=clq(P,alpha-1,0); if(r==1)alpha++; else break;} }
                    printf("TEST p=%d d=%d mask=%llx omega=%d alpha=%d\n",p,d,M,omega,alpha); continue; }
                if(omega<kmin-1 || omega>=maxom) continue;
                int K=omega+1;
                int L=bestk_l(K,p);
                if(L<0 || L>60) continue;
                // decide alpha >= L ?  complement graph
                // greedy first
                // build complement in place
                for(int v=0;v<p;v++){ for(int j=0;j<W;j++) A[v][j]=~A[v][j]; A[v][v>>6]&=~(1ULL<<(v&63)); int r=p&63; if(r)A[v][W-1]&=(1ULL<<r)-1; }
                int found=0, und=0;
                // randomized greedy clique in complement
                for(int t=0;t<30 && !found;t++){
                    uint64_t P[MAXW]; for(int j=0;j<W;j++)P[j]=A[0][j]; int sz=1;
                    while(!empty(P)){ int c=popc(P); int pick=rand()%c; int v=-1;
                        for(int j=0;j<W && v<0;j++){int pcw=__builtin_popcountll(P[j]); if(pick<pcw){uint64_t w=P[j]; for(int q=0;q<pick;q++)w&=w-1; v=j*64+__builtin_ctzll(w);} else pick-=pcw;}
                        sz++; for(int j=0;j<W;j++)P[j]&=A[v][j]; }
                    if(sz>=L) found=1;
                }
                if(!found){
                    for(int i=0;i<d && !found;i++) if(!((M>>i)&1)){
                        int v=gpow[i]; uint64_t P[MAXW];
                        for(int j=0;j<W;j++) P[j]=A[0][j]&A[v][j];
                        nodes=0; nodelimit=lim; aborted=0;
                        int r=clq(P,L-2,0);
                        if(r==1) found=1; else if(r<0) und=1;
                    }
                }
                if(!found){
                    printf("%s p=%d d=%d mask=%llx pc=%d omega=%d -> R(%d,%d) >= %d (known %d)\n",
                        und?"UNDECIDED":"IMPROVE", p,d,M,pc,omega,K,L,p+1,Bnd[K][L]);
                    fflush(stdout);
                }
            }
        }
        fprintf(stderr,"p=%d done graphs=%lld\n",p,ngraphs);
    }
    return 0;
}
