"""Independent verifier for two-block cyclotomic Ramsey graphs.
Builds the graph from scratch (no rotation tricks, no symmetry reduction)
and checks  omega(G) < K  and  alpha(G) < L  with a SAT solver
(cardinality encoding), i.e. a method unrelated to the C search code.
usage: python3 verify.py p d M1 M2 T t0 cfg K L [out.txt]
"""
import sys, itertools
from pysat.card import CardEnc, EncType
from pysat.solvers import Cadical153

def primroot(p):
    fs = [q for q in range(2, p) if (p-1) % q == 0 and all(q % r for r in range(2, int(q**.5)+1))]
    for g in range(2, p):
        if all(pow(g, (p-1)//q, p) != 1 for q in fs):
            return g

CFG = [(0,0,0,0,0),(1,0,1,0,0),(1,0,2,0,0),(1,1,1,2,0),(1,1,1,2,1),(1,1,1,1,0),(1,1,1,1,1),(1,1,3,0,0),(1,1,3,0,1)]

def build(p, d, M1, M2, T, t0, cfg):
    g = primroot(p)
    ind = {}
    x = 1
    for j in range(p-1):
        ind[x] = j; x = x*g % p
    cls = lambda u: ind[u % p] % d
    inS = lambda M, u: u % p != 0 and (M >> cls(u)) & 1
    inT = lambda u: (t0 if u % p == 0 else (T >> cls(u)) & 1)
    hasU, hasV, au, av, uv = CFG[cfg]
    V = [(x, 1) for x in range(p)] + [(x, 2) for x in range(p)]
    if hasU: V.append('u')
    if hasV: V.append('v')
    idx = {v: i for i, v in enumerate(V)}
    E = set()
    for a in range(p):
        for b in range(p):
            if a < b and inS(M1, b-a): E.add((idx[(a,1)], idx[(b,1)]))
            if a < b and inS(M2, b-a): E.add((idx[(a,2)], idx[(b,2)]))
            if inT(b-a): E.add(tuple(sorted((idx[(a,1)], idx[(b,2)]))))
    for ap, ok, msk in (('u', hasU, au), ('v', hasV, av)):
        if not ok: continue
        for x in range(p):
            if msk & 1: E.add(tuple(sorted((idx[(x,1)], idx[ap]))))
            if msk & 2: E.add(tuple(sorted((idx[(x,2)], idx[ap]))))
    if hasU and hasV and uv: E.add(tuple(sorted((idx['u'], idx['v']))))
    # symmetry sanity: S1,S2 must be symmetric
    for u in range(1, p):
        assert inS(M1, u) == inS(M1, -u) and inS(M2, u) == inS(M2, -u)
    return len(V), E

def has_kset(n, adjpairs_ok, k):
    """Is there a k-subset all of whose pairs satisfy adjpairs_ok?  SAT."""
    s = Cadical153()
    top = n
    for i in range(n):
        for j in range(i+1, n):
            if not adjpairs_ok(i, j):
                s.add_clause([-(i+1), -(j+1)])
    enc = CardEnc.atleast(lits=list(range(1, n+1)), bound=k, top_id=top, encoding=EncType.seqcounter)
    for c in enc.clauses: s.add_clause(c)
    r = s.solve()
    s.delete()
    return r

if __name__ == '__main__':
    p, d, M1, M2, T, t0, cfg, K, L = sys.argv[1:10]
    p, d, t0, cfg, K, L = int(p), int(d), int(t0), int(cfg), int(K), int(L)
    M1, M2, T = int(M1, 16), int(M2, 16), int(T, 16)
    n, E = build(p, d, M1, M2, T, t0, cfg)
    print(f"n={n} edges={len(E)}")
    adj = lambda i, j: (min(i,j), max(i,j)) in E
    c = has_kset(n, adj, K)
    print(f"has K_{K}: {c}")
    a = has_kset(n, lambda i, j: not adj(i, j), L)
    print(f"has independent {L}-set: {a}")
    ok = (not c) and (not a)
    print("VERIFIED: R(%d,%d) > %d" % (K, L, n) if ok else "FAILED")
    if len(sys.argv) > 10 and ok:
        with open(sys.argv[10], 'w') as f:
            f.write(f"{n}\n")
            for (i, j) in sorted(E): f.write(f"{i} {j}\n")
