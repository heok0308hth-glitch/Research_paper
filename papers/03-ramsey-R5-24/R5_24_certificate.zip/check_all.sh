#!/bin/sh
# Reproduce the verification of R(5,24) >= 565.
set -e
gcc -O3 -o mcq mcq.c
python3 -c "
import verify
p=281;n,E=verify.build(p,4,1,1,4,0,3);g=verify.primroot(p);h=pow(g,4,p)
A=lambda f: all(tuple(sorted((f(i),f(j)))) in E for i,j in E)
print('translation aut',A(lambda i:(i+1)%p if i<p else (p+(i-p+1)%p if i<2*p else i)))
print('multiplier aut',A(lambda i:h*i%p if i<p else (p+h*(i-p)%p if i<2*p else i)))
print('copy-swap aut',A(lambda i:i+p if i<p else (i-p if i<2*p else (2*p+1 if i==2*p else 2*p))))
print('K5 present (SAT):',verify.has_kset(n,lambda i,j:(min(i,j),max(i,j)) in E,5))"
for k in 0 1 2 3 4 5 6; do ./mcq sub$k.txt 22; done
