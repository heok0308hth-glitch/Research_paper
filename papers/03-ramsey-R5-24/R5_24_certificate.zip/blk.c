// Two-block cyclotomic graphs with optional apex vertices (off-diagonal
// generalisation of the Mathon/Shearer doubling construction).
// Vertex set: Z_p x {1,2}  (+ apex u, v).
//   (x,1)~(y,1) iff y-x in S1 ; (x,2)~(y,2) iff y-x in S2 ;
//   (x,1)~(y,2) iff y-x in T (T may contain 0 via bit t0) ;
//   u adjacent to copy set au (bit0 copy1, bit1 copy2), v to av, u~v iff uv.
// S1,S2,T unions of cyclotomic classes of index d.  Automorphisms:
// translations and multipliers by the d-th powers  ->  every clique can be
// assumed to contain (0,c) and a second vertex from a short list of orbit reps.
// usage: blk pmin pmax dmin dmax mode nodelimit [boundsfile] [kmin]
//   mode 0: S2 in {S1, comp S1};  mode 1: S2 free
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#define MAXW 36
#define MAXV (MAXW*64)
static int W, W1, P2, UA, VA, p, NV;
static uint64_t A[MAXV][MAXW], C[MAXV][MAXW];
static uint64_t (*G)[MAXW];
static int Bnd[64][128];
static long long nodes, nodelimit; static int aborted; static int RLO,RHI,FL;
static inline int popc(const uint64_t*x){int c=0;for(int i=0;i<W;i++)c+=__builtin_popcountll(x[i]);return c;}
static inline int empty(const uint64_t*x){for(int i=0;i<W;i++)if(x[i])return 0;return 1;}
static int ordv[48][MAXV], colv[48][MAXV];
static int clq(uint64_t*P,int need,int depth){
    if(need<=0) return 1;
    if(++nodes>nodelimit){aborted=1;return -1;}
    int cnt=popc(P); if(cnt<need) return 0; if(need==1) return cnt>0;
    uint64_t Q[MAXW],R[MAXW]; memcpy(Q,P,8*W);
    int n=0,c=0,*ord=ordv[depth],*col=colv[depth];
    while(!empty(Q)){ c++; memcpy(R,Q,8*W);
        for(int w=0;w<W;w++) while(R[w]){int b=__builtin_ctzll(R[w]);int v=w*64+b;R[w]&=R[w]-1;Q[w]&=~(1ULL<<b);
            for(int j=0;j<W;j++)R[j]&=~G[v][j]; ord[n]=v;col[n]=c;n++;} }
    uint64_t PP[MAXW]; memcpy(PP,P,8*W);
    for(int i=n-1;i>=0;i--){ if(col[i]<need) return 0; int v=ord[i]; uint64_t NP[MAXW];
        for(int j=0;j<W;j++)NP[j]=PP[j]&G[v][j]; int r=clq(NP,need-1,depth+1); if(r) return r;
        PP[v>>6]&=~(1ULL<<(v&63)); }
    return 0;
}
static int pw(long long b,long long e,long long m){long long r=1;b%=m;while(e){if(e&1)r=r*b%m;b=b*b%m;e>>=1;}return(int)r;}
static int primroot(int p){int f[32],nf=0,x=p-1;for(int q=2;q*q<=x;q++)if(x%q==0){f[nf++]=q;while(x%q==0)x/=q;}if(x>1)f[nf++]=x;
    for(int g=2;g<p;g++){int ok=1;for(int i=0;i<nf;i++)if(pw(g,(p-1)/f[i],p)==1){ok=0;break;}if(ok)return g;}return -1;}
static int isprime(int n){if(n<2)return 0;for(int q=2;q*q<=n;q++)if(n%q==0)return 0;return 1;}
static int ind[4096], gp[4096];
static int nreps, reps[2][256];   // second-vertex orbit reps for base (0,c)
static int hasU, hasV;
static void setb(uint64_t*r,int v){r[v>>6]|=1ULL<<(v&63);}
static void segrow(uint64_t*row,int base,const char*seg,int x){ // bits base+y for y with seg[(y-x) mod p]
    for(int y=0;y<p;y++){int dd=y-x; if(dd<0)dd+=p; if(seg[dd]) setb(row,base+y);} }
static char s1[4096],s2[4096],tt[4096],tn[4096];
static uint64_t r1a[MAXW],r1b[MAXW],r2a[MAXW],r2b[MAXW];
static void rot(uint64_t*dst,const uint64_t*src,int base,int x){ // dst gets segment of src (bits base..base+p-1) rotated by x
    // bit base+y of dst = bit base+((y-x) mod p) of src
    for(int y=0;y<p;y++){int s=y-x; if(s<0)s+=p; if((src[(base+s)>>6]>>((base+s)&63))&1) setb(dst,base+y);} }
static void build(int au,int av,int uv){
    memset(A,0,sizeof(uint64_t)*MAXW*NV);
    memset(r1a,0,sizeof r1a);memset(r1b,0,sizeof r1b);memset(r2a,0,sizeof r2a);memset(r2b,0,sizeof r2b);
    segrow(r1a,0,s1,0); segrow(r1b,P2,tt,0); segrow(r2a,0,tn,0); segrow(r2b,P2,s2,0);
    // rows by rotation via doubled words: simple per-bit is O(p^2); use word trick
    static uint64_t d1a[2*MAXW+2],d1b[2*MAXW+2],d2a[2*MAXW+2],d2b[2*MAXW+2];
    // build doubled p-bit strings
    #define DBL(d,src,base) memset(d,0,sizeof d); for(int y=0;y<p;y++) if((src[(base+y)>>6]>>((base+y)&63))&1){d[y>>6]|=1ULL<<(y&63); d[(y+p)>>6]|=1ULL<<((y+p)&63);}
    DBL(d1a,r1a,0) DBL(d1b,r1b,P2) DBL(d2a,r2a,0) DBL(d2b,r2b,P2)
    for(int x=0;x<p;x++){
        int off=p-x, ws=off>>6, bs=off&63;
        for(int j=0;j<W1;j++){
            #define EX(d) ((d[ws+j]>>bs)|(bs?(d[ws+j+1]<<(64-bs)):0))
            uint64_t m = (j==W1-1 && (p&63))? ((1ULL<<(p&63))-1) : ~0ULL;
            A[x][j]=EX(d1a)&m; A[x][W1+j]=EX(d1b)&m;
            A[P2+x][j]=EX(d2a)&m; A[P2+x][W1+j]=EX(d2b)&m;
        }
    }
    if(hasU){ for(int x=0;x<p;x++){ if(au&1){setb(A[x],UA);setb(A[UA],x);} if(au&2){setb(A[P2+x],UA);setb(A[UA],P2+x);} } }
    if(hasV){ for(int x=0;x<p;x++){ if(av&1){setb(A[x],VA);setb(A[VA],x);} if(av&2){setb(A[P2+x],VA);setb(A[VA],P2+x);} } }
    if(hasU&&hasV&&uv){setb(A[UA],VA);setb(A[VA],UA);}
    // complement
    for(int v=0;v<NV;v++){ for(int j=0;j<W;j++) C[v][j]=0; }
    uint64_t valid[MAXW]; memset(valid,0,sizeof valid);
    for(int x=0;x<p;x++){setb(valid,x);setb(valid,P2+x);} if(hasU)setb(valid,UA); if(hasV)setb(valid,VA);
    for(int x=0;x<p;x++) for(int c=0;c<2;c++){int v=c?P2+x:x; for(int j=0;j<W;j++)C[v][j]=~A[v][j]&valid[j]; C[v][v>>6]&=~(1ULL<<(v&63));}
    if(hasU){for(int j=0;j<W;j++)C[UA][j]=~A[UA][j]&valid[j]; C[UA][UA>>6]&=~(1ULL<<(UA&63));}
    if(hasV){for(int j=0;j<W;j++)C[VA][j]=~A[VA][j]&valid[j]; C[VA][VA>>6]&=~(1ULL<<(VA&63));}
}
static int nvert(){return 2*p+hasU+hasV;}
// does graph G have a clique of size s?  uses symmetry.  1/0/-1
static int hasclique(int s, long long lim){
    if(s<=1) return 1;
    // apex-only cliques
    int apexmax = hasU+hasV; if(hasU&&hasV && !((G[UA][VA>>6]>>(VA&63))&1)) apexmax=1;
    if(s<=apexmax) return 1;
    int und=0;
    for(int c=0;c<2;c++){
        int x = c?P2:0;
        uint64_t *P0=G[x];
        // apex-only extension of x
        int ap=0; uint64_t AP[MAXW]; memset(AP,0,8*W);
        if(hasU && ((P0[UA>>6]>>(UA&63))&1)) {setb(AP,UA);}
        if(hasV && ((P0[VA>>6]>>(VA&63))&1)) {setb(AP,VA);}
        nodes=0;nodelimit=lim;aborted=0; ap = clq(AP,s-1,0)==1;
        if(ap) return 1;
        for(int r=0;r<nreps;r++){ if(FL>=0 && (c*nreps+r<RLO || c*nreps+r>=RHI)) continue; int w=reps[c][r]; if(!((P0[w>>6]>>(w&63))&1)) continue;
            uint64_t P[MAXW]; for(int j=0;j<W;j++)P[j]=P0[j]&G[w][j];
            nodes=0;nodelimit=lim;aborted=0; int rr=clq(P,s-2,0);
            if(rr==1) return 1; if(rr<0) und=1; }
    }
    return und?-1:0;
}
static int bestl(int k,int n){int b=-1;for(int l=k;l<=60;l++)if(Bnd[k][l]&&Bnd[k][l]<=n)b=l;return b;}
static int envi(const char*k,int dflt){const char*v=getenv(k);return v?(int)strtol(v,0,16):dflt;}
int main(int argc,char**argv){
    int FM1=envi("FM1",-1),FM2=envi("FM2",-1),FT=envi("FT",-1),Ft0=envi("FT0",-1),Fcfg=envi("FCFG",-1);
    RLO=envi("RLO",0); RHI=envi("RHI",9999); FL=envi("FL",-1);
    int pmin=atoi(argv[1]),pmax=atoi(argv[2]),dmin=atoi(argv[3]),dmax=atoi(argv[4]),mode=atoi(argv[5]);
    long long lim=atoll(argv[6]); const char*bf=argc>7?argv[7]:"/home/claude/ramsey/bounds.txt"; int kmin=argc>8?atoi(argv[8]):5;
    int testmode = (kmin==0);
    FILE*f=fopen(bf,"r");int k,l,b,li;while(fscanf(f,"%d %d %d %d",&k,&l,&b,&li)==4){Bnd[k][l]=b;if(l<64)Bnd[l][k]=b;}fclose(f);
    long long ng=0;
    for(p=pmin;p<=pmax;p++){ if(!isprime(p)) continue;
        W1=(p+63)/64; P2=W1*64; UA=2*P2; VA=2*P2+1; W=2*W1+1; NV=2*P2+64;
        int g=primroot(p); long long x=1; for(int j=0;j<p-1;j++){ind[x]=j;gp[j]=(int)x;x=x*g%p;}
        for(int d=dmin;d<=dmax;d++){ if((p-1)%d) continue;
            int symm=((p-1)/d)%2==0, half=d/2, nfree=symm?d:half;
            int negsh = ((p-1)/2)%d; // class shift for negation
            unsigned full=(1u<<d)-1;
            // reps
            nreps=0;
            for(int c=0;c<2;c++){ int n=0; int same=c?P2:0, oth=c?0:P2;
                for(int i=0;i<d;i++) reps[c][n++]=same+gp[i];
                for(int i=0;i<d;i++) reps[c][n++]=oth+gp[i];
                reps[c][n++]=oth+0; nreps=n; }
            for(unsigned m1=1;m1<(1u<<nfree);m1++){
                unsigned M1= symm? m1 : (m1|(m1<<half));
                int nS2 = mode==0? 2 : (1<<nfree);
                for(int i2=0;i2<nS2;i2++){
                    unsigned M2;
                    if(mode==0) M2 = i2==0? M1 : (full&~M1);
                    else { unsigned mm=i2; M2 = symm? mm : (mm|(mm<<half)); }
                    if(M2==0 && mode==1) {}
                    for(unsigned T=0;T<(1u<<d);T++) for(int t0=0;t0<2;t0++){
                        if(FM1>=0 && (M1!=(unsigned)FM1||M2!=(unsigned)FM2||T!=(unsigned)FT||t0!=Ft0)) continue;
                        // canonical under joint rotation (lexicographic on (M1,M2,T))
                        int canon=1;
                        for(int r=1;r<d;r++){
                            unsigned R1=((M1<<r)|(M1>>(d-r)))&full, R2=((M2<<r)|(M2>>(d-r)))&full, RT=((T<<r)|(T>>(d-r)))&full;
                            if(R1<M1 || (R1==M1&&(R2<M2 || (R2==M2&&RT<T)))){canon=0;break;}
                        }
                        if(!canon) continue;
                        for(int u=1;u<p;u++){int cl=ind[u]%d; s1[u]=(M1>>cl)&1; s2[u]=(M2>>cl)&1; tt[u]=(T>>cl)&1;
                            int cn=(cl+negsh)%d; tn[u]=(T>>cn)&1;}  // tn[u] = [ -u in T ]
                        s1[0]=s2[0]=0; tt[0]=tn[0]=t0;
                        // apex configurations
                        static const int cfg[][5]={{0,0,0,0,0},{1,0,1,0,0},{1,0,2,0,0},{1,1,1,2,0},{1,1,1,2,1},{1,1,1,1,0},{1,1,1,1,1},{1,1,3,0,0},{1,1,3,0,1}};
                        for(int ci=0;ci<9;ci++){ if(Fcfg>=0 && ci!=Fcfg) continue;
                            hasU=cfg[ci][0]; hasV=cfg[ci][1]; int au=cfg[ci][2], av=cfg[ci][3], uv=cfg[ci][4];
                            build(au,av,uv); ng++;
                            int n=nvert();
                            // sparse side: compare degrees roughly
                            int degA=popc(A[0])+popc(A[P2]), degC=popc(C[0])+popc(C[P2]);
                            uint64_t (*Gs)[MAXW] = degA<=degC? A : C;
                            uint64_t (*Gd)[MAXW] = degA<=degC? C : A;
                            G=Gs; int om=1, und=0;
                            while(om<12){ int r=hasclique(om+1, 20000000); if(r==1) om++; else {if(r<0)und=1; break;} }
                            if(und || om>=11) continue;
                            if(testmode){ G=Gd; int al=om; while(al<40){int r=hasclique(al+1,lim); if(r==1)al++; else break;}
                                printf("TEST p=%d d=%d M1=%x M2=%x T=%x t0=%d cfg=%d n=%d omega=%d alpha=%d\n",p,d,M1,M2,T,t0,ci,n,om,al); fflush(stdout); continue; }
                            int K=om+1; if(K<kmin) continue;
                            int L=bestl(K,n); if(FL>=0) L=FL; if(L<0||L>60) continue;
                            if(FL>=0){fprintf(stderr,"deciding alpha>=%d n=%d omega=%d reps %d..%d\n",L,n,om,RLO,RHI);}
                            G=Gd; int r=hasclique(L,lim);
                            if(r!=1){ printf("%s p=%d d=%d M1=%x M2=%x T=%x t0=%d cfg=%d n=%d omega=%d -> R(%d,%d) >= %d (known %d)\n",
                                r<0?"UNDECIDED":"IMPROVE",p,d,M1,M2,T,t0,ci,n,om,K,L,n+1,Bnd[K][L]); fflush(stdout);}
                        }
                    }
                }
            }
            fprintf(stderr,"p=%d d=%d graphs=%lld\n",p,d,ng);
        }
    }
    return 0;
}
