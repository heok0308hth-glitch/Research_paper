Certificate for  R(5,24) >= 565
================================
Graph: 564 vertices, 39,902 edges, clique number 4, independence number 23.

FILES
  R5_24_graph_564.g6        graph6 string (vertices 0..563)
  R5_24_graph_564.adj       564 lines of 0/1 adjacency rows
  R5_24_graph_564.edgelist  edge list (0-based)
  Vertex labels: 0..280 = (x,1), 281..561 = (x,2), 562 = u, 563 = v.

CONSTRUCTION (to rebuild independently)
  p = 281, g = 3 (least primitive root), C_i = { g^(4j+i) mod p },  i = 0..3.
  (x,1)~(y,1)  iff  y-x in C_0        (x,2)~(y,2)  iff  y-x in C_0
  (x,1)~(y,2)  iff  y-x in C_2        u ~ all (x,1),  v ~ all (x,2),  u !~ v.

VERIFICATION
  * Any exact clique solver run directly on the graph should report
      clique number 4  and  clique number of the complement 23.
  * Fast symmetry-reduced check (about 15 minutes on 2 cores):  sh check_all.sh
      - confirms translation, multiplier (h in C_0) and copy-swap automorphisms,
      - confirms K5-freeness with a SAT solver (pysat / CaDiCaL),
      - runs mcq.c on the 7 subproblems sub0..sub6.txt; each must print NO_CLIQUE
        for K = 22. These are the complement graphs induced on the common
        non-neighbourhood of vertex (0,1) and one of the 7 orbit representatives.
  * proof_log_K22.txt : node counts and timings of our run.

  Requirements: gcc, python3, pip install python-sat

OTHER CODE (search, for reference)
  cyc.c, cycq.c  single-block cyclotomic search (prime / prime-power order)
  blk.c          two-block cyclotomic search with apex vertices
  bounds.py      table of known lower bounds (DS1 rev. 18) closed under 2.3.e/g/h/i
  verify.py      independent graph builder + SAT checker
  tabu.c         heuristic independent-set search
