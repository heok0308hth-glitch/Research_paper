// k-fixed tabu search for an independent set of size k (minimise edges inside S)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int n,m; unsigned char adj[1200][1200]; int inS[1200], cnt[1200], tabu[1200];
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); int k=atoi(argv[2]); long long iters=atoll(argv[3]); srand(atoi(argv[4]));
  fscanf(f,"%d",&n); int a,b; while(fscanf(f,"%d %d",&a,&b)==2){adj[a][b]=adj[b][a]=1;}
  int S[64]; memset(inS,0,sizeof inS);
  for(int i=0;i<k;){int v=rand()%n; if(!inS[v]){inS[v]=1;S[i++]=v;}}
  for(int v=0;v<n;v++){cnt[v]=0;for(int i=0;i<k;i++) if(adj[v][S[i]])cnt[v]++;}
  int cost=0; for(int i=0;i<k;i++) cost+=cnt[S[i]]; cost/=2; int best=cost;
  for(long long it=0;it<iters;it++){
    if(cost==0){printf("FOUND independent set size %d at iter %lld:",k,it);for(int i=0;i<k;i++)printf(" %d",S[i]);printf("\n");return 0;}
    // pick worst conflicting vertex in S (random among max), and best outside vertex
    int bi=-1,bv=-1,bd=1<<30;
    // candidates: out vertex u with minimal cnt[u] - adj[u][S[i]] ; in vertex with max cnt
    int maxc=-1; for(int i=0;i<k;i++) if(cnt[S[i]]>maxc && tabu[S[i]]<=it) maxc=cnt[S[i]];
    int cand[64],nc=0; for(int i=0;i<k;i++) if(cnt[S[i]]==maxc && tabu[S[i]]<=it) cand[nc++]=i;
    if(nc==0){cand[nc++]=rand()%k;}
    int i=cand[rand()%nc]; int v=S[i];
    int ties=0;
    for(int u=0;u<n;u++) if(!inS[u] && tabu[u]<=it){ int dlt=cnt[u]-adj[u][v]-cnt[v];
      if(dlt<bd){bd=dlt;bv=u;ties=1;} else if(dlt==bd && rand()%(++ties)==0) bv=u; }
    if(bv<0) continue;
    // swap v out, bv in
    inS[v]=0; inS[bv]=1; S[i]=bv; cost+=bd;
    for(int w=0;w<n;w++){ cnt[w]+=adj[w][bv]-adj[w][v]; }
    tabu[v]=it+7+rand()%10; tabu[bv]=it+3;
    if(cost<best){best=cost;}
    if(it%2000000==0){fprintf(stderr,"it %lld cost %d best %d\n",it,cost,best);}
  }
  printf("NOTFOUND best=%d\n",best); return 0;
}
